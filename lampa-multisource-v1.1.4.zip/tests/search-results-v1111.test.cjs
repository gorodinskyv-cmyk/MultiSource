'use strict';
const fs = require('fs'), vm = require('vm'), assert = require('node:assert/strict');
const src = fs.readFileSync(require('path').join(__dirname, '..', 'lampa-multisource-v1.1.4.js'),'utf8');
assert.match(src,/var VERSION = '1\.1\.4'/);
const code=src.replace('  function host(url) {',`window.__test={splitSearchNames, validReleaseYear, posterUrl, getPosterFromElement, parseUASearch, parseUADetail};\n  function host(url) {`);
function el(text,attrs={}) { return {textContent:text||'',getAttribute:(k)=>attrs[k]||'',querySelector(){return null},querySelectorAll(){return []}}; }
function mockCard(name,year,poster,original='') {
  const image = el('',{alt:name,'data-src':poster,src:'data:image/gif;base64,R0lGODlhAQABAA'});
  image.tagName='IMG';
  const title=el(name), yearEl=year?el(year):null, originalEl=original?el(original):null;
  const card = {textContent:`7.2 ${year} ${name}`,getAttribute:(x)=>x==='data-year'?year:'',
    querySelector(sel) {if (sel.startsWith('.short-title')) return title;
      if (sel.startsWith('.original-title')) return originalEl;
      if (sel.startsWith('.year')) return yearEl;
      if (sel==='img') return image;
      return null;},
    querySelectorAll(sel){if (sel==='img')return [image];return [];}};
  const a = {textContent:name,getAttribute:(x)=>x==='href'?'/12000-movie.html':'',closest:()=>card,querySelector:(x)=>x==='img'?image:null};
  return a;
}
const a=mockCard('Красуня та чудовиськоBeauty and the Beast','2017','/uploads/beauty.jpg');
const b=mockCard('Кришталеве озероCrystal Lake','2026','https://uaserials.com/uploads/crystal.jpg');
b.getAttribute=(x)=> x==='href'?'/12800-kryshtaleve-ozero.html':'';
const doc={querySelectorAll:sel=>sel==='a[href]'?[a,b,b]:[]};
const window={DOMParser: class {parseFromString(){return doc;}},Lampa:null};
const Lampa={}; const sandbox={window,Lampa,DOMParser:window.DOMParser,URL,document:{},navigator:{userAgent:'Android'},Date,Promise,console,Uint8Array,TextDecoder,
setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{}};
vm.runInNewContext(code,sandbox);
const f=window.__test;
assert.equal(f.splitSearchNames('7.72026Кришталеве озероCrystal Lake',{name:'Кришталеве озеро',original_name:'Crystal Lake'}).title,'Кришталеве озеро');
assert.equal(f.splitSearchNames('7.72026Кришталеве озероCrystal Lake',{name:'Кришталеве озеро',original_name:'Crystal Lake'}).originalTitle,'Crystal Lake');
assert.equal(f.splitSearchNames('Красуня та чудовиськоBeauty and the Beast',{}).title,'Красуня та чудовисько');
assert.equal(f.splitSearchNames('Красуня та чудовиськоBeauty and the Beast',{}).originalTitle,'Beauty and the Beast');
assert.equal(f.posterUrl('javascript:alert(1)','https://uaserials.com/'), '');
assert.equal(f.posterUrl('/uploads/movie.jpg','https://uaserials.com/x.html'),'https://uaserials.com/uploads/movie.jpg');
assert.equal(f.posterUrl('data:image/gif;base64,aaa','https://uaserials.com/'),'');
assert.equal(f.validReleaseYear('2026'),'2026');
assert.equal(f.validReleaseYear('1888'),'');
const items=f.parseUASearch('<html>test</html>',{name:'Кришталеве озеро',original_name:'Crystal Lake'});
assert.equal(items.length,2);
assert.equal(items[0].title,'Красуня та чудовисько');
assert.equal(items[0].originalTitle,'Beauty and the Beast');
assert.equal(items[0].year,'2017');
assert.equal(items[0].poster,'https://uaserials.com/uploads/beauty.jpg');
assert.equal(items[1].title,'Кришталеве озеро');
assert.equal(items[1].originalTitle,'Crystal Lake');
assert.equal(items[1].year,'2026');
assert.equal(items[1].poster,'https://uaserials.com/uploads/crystal.jpg');
assert.match(src,/function addResultCard\(/);
assert.match(src,/function enrichResultCards\(/);
assert.match(src,/var pending = items/);
assert.match(src,/ms-result-original/);
assert.match(src,/ms-result-poster/);
assert.match(src,/function renderEpisodeCatalog\(/);
assert.match(src,/function playSelectedEpisode\(/);
console.log('PASS v1.1.1: title separation, posters, year, card parsing, deduplication, enrichment, episode playback unchanged');
