/*
 * Приклад другого джерела для Lampa MultiSource.
 * ЦЕ ШАБЛОН, НЕ ГОТОВИЙ ПРОВАЙДЕР. Замініть адресу на власний легальний JSON API.
 * Підключається окремим JS-файлом ПІСЛЯ lampa-multisource.js.
 * Контракт API:
 * GET https://media.example.org/api/search?title=...
 *   => {"results":[{"title":"Назва", "year":"2026", "id":"movie-1"}]}
 * GET https://media.example.org/api/items/movie-1
 *   => {"streams":[{"title":"1080p", "url":"https://cdn.example.org/video.m3u8",
 *                    "season":1,"episode":1,"voice":"Українська"}]}
 * URL повинні вести лише на матеріали, на відтворення яких є дозвіл.
 */
(function () {
  'use strict';
  if (!window.LampaMultiSource) return;
  var API = 'https://media.example.org'; // ЗАМІНІТЬ
  window.LampaMultiSource.registerSource({
    id: 'example_json',
    name: 'Мій JSON-провайдер',
    search: function (movie, context) {
      var title = movie.title || movie.name || movie.original_title || '';
      return context.request(API + '/api/search?title=' + encodeURIComponent(title)).then(function (raw) {
        var data = JSON.parse(raw);
        return data.results || [];
      });
    },
    getStreams: function (item, context) {
      var id = encodeURIComponent(item.id || '');
      return context.request(API + '/api/items/' + id).then(function (raw) {
        var data = JSON.parse(raw);
        return { streams: data.streams || [], pageUrl: data.pageUrl || '' };
      });
    }
  });
})();
