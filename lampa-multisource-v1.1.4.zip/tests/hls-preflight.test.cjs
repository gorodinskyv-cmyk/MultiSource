const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, '..', 'lampa-multisource-v1.1.4.js'), 'utf8');
const marker = '  function askDirectUrl(title) {';
const instrumented = source.replace(marker, '  window.__check = checkHlsStream;\n' + marker);
const memory = {};
const win = {
  fetch: async () => { throw new Error('not set'); },
  AbortController,
  Lampa: {
    Utils: { hash: s => s.length },
    Storage: { get: (k,d) => k in memory ? memory[k] : d, set: (k,v) => {memory[k]=v;} }
  }
};
const context = { window:win, Lampa:win.Lampa, document:{}, URL, console,
  setTimeout: (f,ms) => 1, clearTimeout: () => {},
  setInterval: () => 1, clearInterval: () => {},
  Promise, Date, Array, Object, Number, TextEncoder, TextDecoder, Uint8Array, atob };
vm.runInNewContext(instrumented, context);
const url = 'https://example.org/t/secretToken/index.m3u8';
function resp(status, body, ctype) {
  return { ok: status >= 200 && status <= 299, status,
    headers: {get: () => ctype || 'application/vnd.apple.mpegurl'},
    text: async () => body };
}
(async () => {
  win.fetch = async () => resp(200, '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000\n360/index.m3u8');
  let result = await win.__check(url);
  assert.equal(result.ok,true);assert.equal(result.reason,'valid_hls');assert.equal(result.variants,1);
  assert.equal(result.host, 'example.org');assert(!JSON.stringify(result).includes('secretToken'));
  win.fetch = async () => resp(200, '#EXTM3U\n#EXTINF:4.0,\nseg1.ts');
  result = await win.__check(url);assert.equal(result.ok,true);assert.equal(result.segments,1);
  win.fetch = async () => resp(403, '<h1>Forbidden</h1>', 'text/html');
  result = await win.__check(url);assert.equal(result.ok,false);assert.equal(result.status,403);assert.equal(result.reason,'http');
  assert(!JSON.stringify(result).includes('secretToken'));
  win.fetch = async () => resp(404, 'not found', 'text/plain');
  result = await win.__check(url);assert.equal(result.status,404);assert.equal(result.ok,false);
  win.fetch = async () => resp(200, '<html><body>Page</body></html>', 'text/html');
  result = await win.__check(url);assert.equal(result.reason,'not_hls');assert.equal(result.ok,false);
  win.fetch = async () => {throw new TypeError('Failed to fetch')};
  result = await win.__check(url);assert.equal(result.reason,'network');assert.equal(result.ok,false);
  win.fetch = async () => {const e=new Error('aborted');e.name='AbortError';throw e;};
  result = await win.__check(url);assert.equal(result.reason,'timeout');
  result = await win.__check('http://insecure.example/a.m3u8');assert.equal(result.reason,'invalid_url');
  result = await win.__check('https://example.org/a.mp4');assert.equal(result.reason,'not_hls');assert.equal(result.ok,true);
  const oldFetch = win.fetch; delete win.fetch;
  result = await win.__check(url);assert.equal(result.reason,'fetch_unavailable');assert.equal(result.ok,false);
  win.fetch = oldFetch;
  assert(source.includes("var VERSION = '1.1.4'"));
  assert(source.includes('play(stream, [stream], movieTitle)'));
  assert(source.includes('Перевіряємо доступність HLS для серії'));
  assert(source.includes('checkHlsStream: checkHlsStream'));
  assert(source.includes('Вставити HLS/MP4 (тест)'));
  assert(source.includes("if (state === 'episodes') renderResults();"));
  console.log('MultiSource v1.1.4: 15 network/flow checks passed');
})().catch(e => {console.error(e);process.exitCode=1;});
