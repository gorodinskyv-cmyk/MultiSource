'use strict';
const fs=require('fs'), assert=require('node:assert/strict'), path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','lampa-multisource-v1.1.4.js'),'utf8');
const a=src.indexOf('    function seasonNumbers(labels) {'),b=src.indexOf('    function chooseSeason(',a);
const c=src.indexOf('    function renderEpisodeCatalog('),d=src.indexOf('    function supplementEpisodeCatalog(',c);
assert(a>=0&&b>a&&c>b&&d>c);
const factory=new Function('isEpisodeWatched',`let state='results',lastEpisodeCatalog=null,episodeRows=[],episodeContext=null,
 selectedSeason=null,selectedVoice='',selectedViewed='all';
 let titles=[],cards=[],headers=[],captionCalls=0,viewportCalls=0;
 const object={movie:{id:123}},currentSource='uaserials';
 const scroll={append(){}};
 const $=()=>({});
 const sourceCaption=()=>{captionCalls++}; const beginList=()=>{};
 const addRow=(title,subtitle,fn,cls)=>{titles.push(title);if(cls==='ms-section')headers.push(title);};
 const episodeCard=(group)=>{cards.push(group.season+':'+group.episode)};
 const scheduleViewport=()=>{viewportCalls++},enableController=()=>{},attachSeasonMetadata=()=>{};
 const renderResults=()=>{};
 ${src.slice(a,b)}
 ${src.slice(c,d)}
 return {run:(labels)=>{titles=[];cards=[];headers=[];renderEpisodeCatalog(labels,{},'Тест',false,'');
   return {cards,titles,headers,state,count:episodeContext.labels.length,selectedSeason,selectedVoice,captionCalls,viewportCalls};},
  set:(season,voice,viewed)=>{selectedSeason=season;selectedVoice=voice;selectedViewed=viewed;}};`);
const ui=factory((_movie,season,episode)=>season===1&&episode===2);
const labels=[
{season:1,episode:1,voice:'DubX'},{season:1,episode:1,voice:'Postmodern'},
{season:1,episode:2,voice:'DubX'},{season:1,episode:2,voice:'Postmodern'},
{season:2,episode:1,voice:'Postmodern'}];
let r=ui.run(labels);
assert.deepEqual(r.cards,['1:1','1:2','2:1']);
assert(r.titles.includes('Серій: 3'));
assert(r.headers.includes('Сезон 2'));
ui.set(1,'Postmodern','unwatched');r=ui.run(labels);
assert.deepEqual(r.cards,['1:1']);
ui.set(2,'DubX','all');r=ui.run(labels);
assert.equal(r.selectedVoice,''); // Voice in another season is reset.
assert.deepEqual(r.cards,['2:1']);
assert.equal(r.captionCalls,3);
console.log('PASS: unique episode count, multi-voice dedupe, season/voice/status filters, toolbar sync');
