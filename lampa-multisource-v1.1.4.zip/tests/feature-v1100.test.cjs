const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const p=require('node:path').join(__dirname,'..','lampa-multisource-v1.1.4.js');
const source=fs.readFileSync(p,'utf8');
assert.match(source,/var VERSION = '1\.1\.4'/);
const marker='  function findEpisode(streams, selected) {';
const code=source.replace(marker, `window.__test={tmdbSeriesId, tmdbEpisodeInfo, episodeImagePath, watchedEpisodeKey,isEpisodeWatched,setEpisodeWatched,getQualitySetting,extractHlsVariants};\n`+marker);
const state={};
let calls=[];
let mockEpisodes=[{episode_number:1,name:'Табір Кришталь',still_path:'/foo/bar.jpg',air_date:'2026-10-15'},
 {episode_number:2,name:'Друге випробування',still_path:'/ABC-def.png'}];
const Lampa={Storage:{get:(k,f)=>Object.prototype.hasOwnProperty.call(state,k)?state[k]:f,set:(k,v)=>state[k]=v},
 Utils:{hash:(s)=>s.length},Api:{sources:{tmdb:{get(path,options,success){calls.push({path,options});success({episodes:mockEpisodes})}}}}};
const window={Lampa,isSecureContext:true,crypto:{subtle:{}},fetch:null};
const sandbox={window,Lampa,document:{},URL,navigator:{userAgent:'Android 14'},location:{protocol:'https:'},
 setTimeout(){return 1},clearTimeout(){},setInterval(){return 2},clearInterval(){},
 console,Promise,Date,Number,Array,Object,Uint8Array,TextEncoder,TextDecoder,atob};
vm.runInNewContext(code,sandbox);
const h=window.__test;
assert.equal(h.tmdbSeriesId({id:213562,source:'tmdb',name:'Crystal Lake'}),213562);
assert.equal(h.tmdbSeriesId({id:2,tmdb_id:213562,source:'cub',name:'Crystal Lake'}),213562);
assert.equal(h.tmdbSeriesId({id:100,type:'movie'}),0);
assert.equal(h.episodeImagePath('/still.jpg'),'https://image.tmdb.org/t/p/w300/still.jpg');
assert.equal(h.episodeImagePath('https://untrusted.com/a.jpg'),'');
(async()=>{
 const items=await h.tmdbEpisodeInfo({id:213562,source:'tmdb',name:'Crystal Lake'},1);
 assert.equal(items.length,2);
 assert.equal(items[0].name,'Табір Кришталь');
 assert.equal(calls[0].path,'tv/213562/season/1');
 assert.equal(calls[0].options.language,'uk-UA');
 assert.equal(h.isEpisodeWatched({id:213562,source:'tmdb'},1,8,'uaserials'),false);
 assert.equal(h.setEpisodeWatched({id:213562,source:'tmdb'},1,8,'uaserials',true),true);
 assert.equal(h.isEpisodeWatched({id:213562,source:'tmdb'},1,8,'uaserials'),true);
 assert.equal(h.isEpisodeWatched({id:213562,source:'tmdb'},1,7,'uaserials'),false);
 assert.equal(h.setEpisodeWatched({id:213562,source:'tmdb'},1,8,'uaserials',false),false);
 assert.equal(h.isEpisodeWatched({id:213562,source:'tmdb'},1,8,'uaserials'),false);
 assert.equal(h.getQualitySetting(),'auto');
 state.ms_v1_quality='720';assert.equal(h.getQualitySetting(),'720');
 state.ms_v1_quality='random';assert.equal(h.getQualitySetting(),'auto');
 const master='#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=1920x1080,BANDWIDTH=2128000\n../hi/index.m3u8\n#EXT-X-STREAM-INF:RESOLUTION=1280x720,BANDWIDTH=1096000\n../mid/index.m3u8\n#EXT-X-STREAM-INF:RESOLUTION=854x480,BANDWIDTH=714000\n../low/index.m3u8';
 const out=h.extractHlsVariants(master,'https://calypso.tortuga.tw/t/token1/token2/index.m3u8');
 assert.deepEqual(Array.from(out.map(x=>x.height)),[1080,720,480]);
 assert.equal(out[1].url,'https://calypso.tortuga.tw/t/token1/mid/index.m3u8');
 assert.equal(h.extractHlsVariants('#EXTM3U\n#EXTINF:5\nsegment1.ts','https://example.org/index.m3u8').length,0);
 assert.match(source,/function chooseSeason\(/);assert.match(source,/function chooseVoice\(/);
 assert.match(source,/function chooseEpisodeVoice\(/);assert.match(source,/function episodeCard\(/);
 assert.match(source,/function attachSeasonMetadata\(/);assert.match(source,/ms-list-end-spacer/);
 assert.match(source,/playSelectedEpisode\(/);assert.match(source,/checkHlsStream\(stream\.url/);
 assert.match(source,/var setting = getQualitySetting\(\)/);
 assert.match(source,/function getSources\(/);
 console.log('PASS: TMDB API, stills, language, watched flags, quality, HLS variants, Android-safe UI structure');
})().catch(e=>{console.error(e);process.exitCode=1});
