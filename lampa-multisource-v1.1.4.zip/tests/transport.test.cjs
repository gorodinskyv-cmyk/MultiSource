const fs = require('node:fs');
const assert = require('node:assert/strict');
const source = fs.readFileSync(process.argv[2], 'utf8');
const begin = source.indexOf('  function ajaxText(');
const end = source.indexOf('  function testAdapter()', begin);
assert.ok(begin > 0 && end > begin);
const implementation = source.slice(begin, end);
const factory = new Function('getAdapterUrl', 'host', 'rawRequest', 'fetchDiagnostics', 'companionHtml', implementation + '\nreturn ajaxText;');
const host = url => new URL(url).hostname;
async function test(label, adapter, directWorks, companionWorks, expectedCalls, transport) {
  const calls = [];
  const diag = { transport:'', lastRequest:'', lastError:'', tortugaDirect:'not_tried', tortugaFallback:false };
  const rawRequest = url => {
    calls.push(url);
    if (url === 'https://tortuga.tw/embed-test' && !directWorks) return Promise.reject(new Error('blocked by CORS'));
    return Promise.resolve(url.includes('/fetch?') ? 'worker-html' : 'browser-html');
  };
  const ajaxText = factory(() => adapter, host, rawRequest, diag, () => companionWorks ? Promise.resolve('companion-html') : Promise.reject(new Error('No companion')));
  const got = await ajaxText('https://tortuga.tw/embed-test', 5000);
  assert.equal(calls.length, expectedCalls, label);
  assert.equal(diag.transport, transport, label);
  assert.equal(diag.lastRequest, 'tortuga.tw / player HTML');
  if (transport === 'adapter-fallback') {
    assert.equal(diag.tortugaDirect, 'unavailable');
    assert.equal(diag.tortugaFallback, true);
    assert.equal(got, 'worker-html');
  }
  if (transport === 'chrome-companion') {
    assert.equal(diag.companion, 'success');
    assert.equal(got, 'companion-html');
  }
  if (transport === 'browser') {
    assert.equal(diag.tortugaDirect, 'success');
    assert.equal(diag.tortugaFallback, false);
    assert.equal(got, 'browser-html');
  }
}
(async () => {
  await test('direct success', 'https://worker.example', true, false, 1, 'browser');
  await test('extension success', 'https://worker.example', false, true, 1, 'chrome-companion');
  await test('fallback to worker', 'https://worker.example', false, false, 2, 'adapter-fallback');
  await test('no adapter', '', true, false, 1, 'direct');
  // UASerials search always uses worker if configured, preserving existing behavior.
  const diag = {};
  const paths = [];
  const ajaxText = factory(()=>'https://worker.example', host, url=>{paths.push(url); return Promise.resolve('ok');}, diag, ()=>Promise.reject(new Error('not installed')));
  await ajaxText('https://uaserials.com/search/example/');
  assert.match(paths[0], /^https:\/\/worker\.example\/fetch\?url=/);
  assert.equal(diag.transport, 'adapter');
  console.log('PASS: browser-first, Chrome companion, Worker fallback, no-adapter, UASerials search');
})().catch(e=>{console.error(e);process.exit(1)});
