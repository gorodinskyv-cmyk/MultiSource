const fs = require('node:fs');
const assert = require('node:assert/strict');
const code = fs.readFileSync(require('node:path').join(__dirname, '..', 'lampa-multisource-v1.1.4.js'), 'utf8');
assert.match(code, /var VERSION = '1\.1\.4'/);
assert.match(code, /window\.addEventListener\('resize', scheduleViewport, false\)/);
assert.match(code, /window\.removeEventListener\('resize', scheduleViewport, false\)/);
assert.match(code, /scroll\.reset\(\)/);
assert.match(code, /scroll\.body\(\)\[0\]\.addEventListener\('wheel', onListWheel/);
assert.match(code, /☰ Обрати серію \(резервне меню\)/);
// Verify all eight episodes are available in the built-in Lampa picker,
// independently of the viewport size of the plugin itself.
let chosen, shown, restored = '';
const Lampa = { Select: {show(o) {shown=o},close() {}}, Controller: {
  enabled() {return {name:'content'}},toggle(id) {restored=id;}
}};
const start=code.indexOf('    function showEpisodePicker(');
const end=code.indexOf('    // Fallback for desktop builds',start);
assert.ok(start>-1 && end>start);
const factory=new Function('window','Lampa','notify','playSelectedEpisode',
  code.slice(start,end)+'\nreturn showEpisodePicker;');
const picker=factory({Lampa},Lampa,()=>{},(entry,label,movie)=>chosen={entry,label,movie});
const episodes=Array.from({length:8},(_,i)=>({title:`Сезон 1 • Серія ${i+1}`,season:1,episode:i+1,voice:'HDrezka Studio'}));
picker(episodes,{url:'https://example.invalid/embed'},'Кришталеве озеро');
assert.equal(shown.items.length,8);
assert.equal(shown.items[7].title,'Сезон 1 • Серія 8');
shown.onSelect({id:'7'});
assert.equal(chosen.label.episode,8);
assert.equal(restored,'content');
// Test viewport calculation on desktop and constrained screens.
const a=code.indexOf('    function measureViewport() {');
const b=code.indexOf('    function scheduleViewport() {',a);
assert.ok(a>-1 && b>a);
let minusArg='unset', active=true;
let aside = {length:1};
const scroll = { minus(arg){minusArg=arg;} };
const explorer={render(){return {find(){return aside}}}};
const window={innerWidth:1200};
const viewportFactory=new Function('scroll','explorer','window','console','LOG',
  'const active = true;'+code.slice(a,b)+'\nreturn measureViewport;');
const measureViewport=viewportFactory(scroll,explorer,window,console,'TEST');
measureViewport();assert.equal(minusArg,false);
window.innerWidth=540;
measureViewport();assert.equal(minusArg,aside);
console.log('PASS: resize handlers, wheel navigation hook, scroll reset, 8-episode picker, desktop/mobile viewport');
