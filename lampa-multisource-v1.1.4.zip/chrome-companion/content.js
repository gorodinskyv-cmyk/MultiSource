/* MultiSource v1.0.11 companion. No requests are made from the content script. */
(() => {
  'use strict';
  const ORIGIN = 'https://cf.lampa.mx';
  if (location.origin !== ORIGIN) return;
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== ORIGIN) return;
    const m = event.data;
    if (!m || m.channel !== 'multisource:request' ||
        typeof m.id !== 'string' || m.id.length > 100 ||
        typeof m.url !== 'string' || m.url.length > 1900) return;
    let target;
    try { target = new URL(m.url); }
    catch { return; }
    if (target.protocol !== 'https:' ||
        !['tortuga.tw', 'tortuga.wtf'].includes(target.hostname) ||
        target.port || target.username || target.password) return;
    window.postMessage({ channel: 'multisource:ack', id: m.id }, ORIGIN);
    chrome.runtime.sendMessage({ kind: 'ms-public-player-html', url: target.href }, response => {
      if (chrome.runtime.lastError) {
        window.postMessage({ channel: 'multisource:response', id: m.id, ok: false,
          error: 'Companion extension unavailable' }, ORIGIN);
        return;
      }
      window.postMessage({ channel: 'multisource:response', id: m.id,
        ok: !!response?.ok,
        html: response?.ok ? response.html : undefined,
        error: response?.ok ? undefined : (response?.error || 'HTML fetch failed')
      }, ORIGIN);
    });
  });
})();
