'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const code = fs.readFileSync(path.join(__dirname, '..', 'lampa-multisource-v1.1.4.js'), 'utf8');
assert.match(code, /var VERSION = '1\.1\.4'/);
const getPart = (a,b)=>{
  const start=code.indexOf(a),end=code.indexOf(b,start);
  assert(start>=0&&end>start, `missing ${a}`);
  return code.slice(start,end);
};
const toolbarCode=getPart('    // The toolbar is context-aware:', '    function configureAdapter() {');
const FakeNode=class {
  constructor(html=''){this.html=html;this.value='';this.children=[];this.handlers={};}
  text(val){this.value=String(val);return this;}
  on(event,fn){this.handlers[event]=fn;return this;}
  empty(){this.children=[];return this;}
  append(child){this.children.push(child);return this;}
  trigger(name){assert(this.handlers[name],`missing event ${name}`);return this.handlers[name]();}
};
const $=(html)=>new FakeNode(html);
let shown, closed=0, restored='', changedQuery=0, seasonCalls=0, voiceCalls=0, qualityCalls=0,
  viewedCalls=0, refreshCalls=0, pickerCalls=0, renderedCalls=0;
const Lampa={Controller:{enabled:()=>({name:'head'}),toggle:(v)=>{restored=v;}},
  Select:{show:(v)=>{shown=v;},close:()=>{closed++;}}};
let quality='auto';
const toolbar=new FakeNode();
const registry={uaserials:{name:'UASerials'}};
const ctx={labels:[{season:1,episode:1,voice:'Postmodern'}],resolverEntry:{url:'https://example.org/embed'},
  movieTitle:'Гострі картузи',cached:false,failure:''};
const argNames=['$','toolbar','registry','Lampa','getAdapterUrl','getQualitySetting',
  'scheduleViewport','chooseSource','changeQuery','chooseVoice','chooseSeason','chooseViewed','chooseQuality',
  'renderEpisodeCatalog','configureAdapter','askDirectUrl','playOrResolve','showEpisodePicker','openWeb',
  'currentStreams','setStorage'];
const factory=new Function(...argNames, `
let state='episodes',episodeContext=${JSON.stringify(ctx)},currentSource='uaserials',
selectedSeason=1,selectedVoice='Postmodern',selectedViewed='all';
${toolbarCode}
return {sourceCaption,showCatalogFilters,setState:(s)=>state=s,setContext:(x)=>episodeContext=x,
selection:()=>({selectedSeason,selectedVoice,selectedViewed})};`);
const api=factory($,toolbar,registry,Lampa,()=>'https://worker.example',()=>quality,
  ()=>{},()=>{},()=>{changedQuery++;},()=>{voiceCalls++;},()=>{seasonCalls++;},
  ()=>{viewedCalls++;},(after)=>{qualityCalls++;quality='720';after&&after();},
  ()=>{renderedCalls++;},()=>{},()=>{},()=>{refreshCalls++;},()=>{pickerCalls++;},()=>{},[],(key,value)=>{if(key==='quality')quality=value;});
api.sourceCaption();
assert.equal(toolbar.children.length,4,'source/voice/filters/settings');
assert.match(toolbar.children[0].value,/Джерело: UASerials/);
assert.match(toolbar.children[1].value,/ОЗВУЧЕННЯ: Postmodern/);
assert.match(toolbar.children[2].value,/ФІЛЬТРИ/);
assert.match(toolbar.children[3].html,/Налаштування/);
toolbar.children[1].trigger('hover:enter');assert.equal(voiceCalls,1);
toolbar.children[2].trigger('hover:enter');
assert.deepEqual(shown.items.map(x=>x.id),['season','viewed','quality','reset']);
shown.onSelect({id:'season'});assert.equal(seasonCalls,1);
toolbar.children[2].trigger('hover:enter');shown.onSelect({id:'viewed'});assert.equal(viewedCalls,1);
toolbar.children[2].trigger('hover:enter');shown.onSelect({id:'quality'});
assert.equal(qualityCalls,1);assert.equal(renderedCalls,1);
toolbar.children[2].trigger('hover:enter');shown.onSelect({id:'reset'});
assert.deepEqual(api.selection(),{selectedSeason:null,selectedVoice:'',selectedViewed:'all'});
assert.equal(renderedCalls,2);assert.equal(quality,'auto');
toolbar.children[3].trigger('hover:enter');
assert.deepEqual(shown.items.map(x=>x.id),['picker','refresh','adapter','query','direct','credits']);
shown.onSelect({id:'refresh'});assert.equal(refreshCalls,1);
toolbar.children[3].trigger('hover:enter');shown.onSelect({id:'picker'});assert.equal(pickerCalls,1);
api.setState('results');api.setContext(null);api.sourceCaption();
assert.equal(toolbar.children.length,3);
assert.match(toolbar.children[1].html,/Змінити назву пошуку/);
toolbar.children[1].trigger('hover:enter');assert.equal(changedQuery,1);
// The catalog body no longer repeats season/voice/quality rows.
const body=getPart('    function renderEpisodeCatalog(labels, resolverEntry, movieTitle, cached, failure) {',
  '    function supplementEpisodeCatalog(');
assert(!body.includes("addRow('Озвучення:"));
assert(!body.includes("addRow('Сезон:"));
assert(!body.includes("addRow('Якість відео:"));
assert.match(body,/episodeGroups\(labels, null, ''\)\.length/);
assert.match(body,/selectedViewed === 'watched'/);
assert.match(body,/sourceCaption\(\)/);
assert.match(code,/filterButton\.on\('hover:enter', showCatalogFilters\)/);
assert.match(code,/Lampa\.Select\.show\(\{ title: 'Показувати серії'/);
assert.match(code,/Lampa\.Select\.show\(\{ title: 'Оберіть озвучення'/);
assert.match(code,/Lampa\.Select\.show\(\{ title: 'Оберіть сезон'/);
assert.match(code,/onBack: function \(\) \{ Lampa\.Controller\.toggle\(previous\); \}/);
console.log('PASS: contextual toolbar, filter/voice menus, settings fallback, 3 search buttons, no duplicate filter rows');
