/* Local smoke tests without Lampa TV. Run: node tests/smoke.test.js */
'use strict';
var fs = require('fs');
var path = require('path');
var vm = require('vm');
var assert = require('assert');
var context = {
  window: {},
  console: { log: function () {} },
  setTimeout: function () {},
  Promise: Promise
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'lampa-multisource.js'), 'utf8'), context);
var plugin = context.window.LampaMultiSource;
assert(plugin && plugin.version === '1.0.0');
assert.strictEqual(plugin.listSources().length, 1);
assert.strictEqual(plugin.listSources()[0].id, 'uaserials');
assert.strictEqual(plugin.helpers.mediaUrl('https://cdn.test/movie.m3u8', 'https://cdn.test/'), 'https://cdn.test/movie.m3u8');
assert.strictEqual(plugin.helpers.mediaUrl('javascript:alert(1)', 'https://cdn.test/'), '');
assert.strictEqual(plugin.helpers.mediaUrl('http://cdn.test/movie.m3u8', 'https://cdn.test/'), '');
assert.strictEqual(plugin.helpers.escapeHtml('<script>'), '&lt;script&gt;');
var result = plugin.extractDirect('<script>var file="https://cdn.test/video.m3u8";</script>', 'https://uaserials.com/a.html');
assert.strictEqual(result.streams.length, 1);
assert.strictEqual(result.streams[0].url, 'https://cdn.test/video.m3u8');
plugin.registerSource({ id: 'demo', name: 'Demo', search: function () {}, getStreams: function () {} });
assert.strictEqual(plugin.listSources().length, 2);
assert.strictEqual(plugin.unregisterSource('demo'), true);
assert.strictEqual(plugin.unregisterSource('uaserials'), false);
assert.strictEqual(plugin.listSources().length, 1);
console.log('OK — API, registry, escaping, URL validation, direct-stream extraction');
