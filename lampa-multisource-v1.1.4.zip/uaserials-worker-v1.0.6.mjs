/**
 * MultiSource UASerials HTML adapter for Cloudflare Workers (1.0.6).
 * GET /health                -> {ok:true, service:...}
 * GET /fetch?url=<encoded>  -> public HTML from uaserials.com and two exact Tortuga player hosts
 *
 * This is NOT a streaming, authentication or DRM bypass proxy.
 * No cookies, credentials, arbitrary hosts or video content are relayed.
 */
const SERVICE = 'lampa-multisource-uaserials';
const ALLOWED_HOSTS = new Set(['uaserials.com', 'tortuga.wtf', 'tortuga.tw']);
const MAX_HTML_BYTES = 2 * 1024 * 1024;
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Expose-Headers': 'X-MultiSource-Upstream-Status',
  'X-Content-Type-Options': 'nosniff',
};
function reply(body, status = 200, extra = {}) {
  return new Response(body, { status, headers: { ...CORS, ...extra } });
}
function json(value, status = 200) {
  return reply(JSON.stringify(value), status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
}
function allowed(value) {
  try {
    if (!value || value.length > 1900) return null;
    const url = new URL(value);
    if (url.protocol !== 'https:' || !ALLOWED_HOSTS.has(url.hostname) || url.port || url.username || url.password)
      return null;
    if (!/^\/(?:[a-zA-Z0-9_%\-./]+)?$/.test(url.pathname)) return null;
    if (url.href.length > 2000) return null;
    return url;
  } catch { return null; }
}
async function fetchPublicPage(url) {
  let target = url;
  for (let i = 0; i < 3; i++) {
    // Manual redirects are important: do not accidentally proxy a third-party host.
    const requestHeaders = {
      Accept: 'text/html,application/xhtml+xml;q=0.9,text/plain;q=0.5',
      'Accept-Language': 'uk-UA,uk;q=0.9,en;q=0.8',
    };
    // Public UASerials embeds are normally opened in an iframe from uaserials.com.
    // Match that ordinary referrer context for a compatible, non-credentialed GET.
    // This does not bypass access controls or challenges.
    if (target.hostname === 'tortuga.tw' || target.hostname === 'tortuga.wtf') {
      requestHeaders.Referer = 'https://uaserials.com/';
    }
    const response = await fetch(target.toString(), {
      method: 'GET', redirect: 'manual',
      headers: requestHeaders,
      cf: { cacheEverything: false },
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const redirected = response.headers.get('Location');
      const next = redirected && allowed(new URL(redirected, target).toString());
      if (!next || next.hostname !== target.hostname) return json({ ok: false, error: 'Blocked upstream redirect outside origin' }, 502);
      target = next;
      continue;
    }
    if (!response.ok) {
      return json({ ok: false, error: 'Player site returned HTTP ' + response.status,
        upstreamStatus: response.status }, response.status, {
        'X-MultiSource-Upstream-Status': String(response.status),
      });
    }
    const type = String(response.headers.get('content-type') || '').toLowerCase();
    if (type && !/text\/html|application\/xhtml\+xml|text\/plain/.test(type))
      return json({ ok: false, error: 'Unsupported upstream content type' }, 415);
    const declaredSize = Number(response.headers.get('content-length') || 0);
    if (declaredSize > MAX_HTML_BYTES) return json({ ok: false, error: 'HTML response too large' }, 413);
    if (!response.body) return json({ ok: false, error: 'Upstream returned empty body' }, 502);
    const reader = response.body.getReader();
    const pieces = [];
    let length = 0;
    try {
      while (true) {
        const part = await reader.read();
        if (part.done) break;
        length += part.value.byteLength;
        if (length > MAX_HTML_BYTES) {
          await reader.cancel();
          return json({ ok: false, error: 'HTML response exceeds 2 MiB' }, 413);
        }
        pieces.push(part.value);
      }
    } finally { try { reader.releaseLock(); } catch {} }
    const buf = new Uint8Array(length);
    let offset = 0;
    for (const p of pieces) { buf.set(p, offset); offset += p.byteLength; }
    // If the source presents an interactive access challenge, report it rather than bypass it.
    const preview = new TextDecoder().decode(buf.subarray(0, Math.min(buf.length, 8192)));
    if (/<title>\s*just a moment|cf-chl|__cf_chl|captcha.challenge/i.test(preview))
      return json({ ok: false, error: 'Player site requires an interactive browser challenge' }, 403);
    // The tiny Tortuga root/landing page may return HTTP 200 even when the
    // requested embed is unavailable. Do not report it as a valid player page.
    if ((target.hostname === 'tortuga.tw' || target.hostname === 'tortuga.wtf') &&
        length < 700 && /info@tortuga\.tw/i.test(preview) &&
        !/\bfile\s*:\s*[\"']/i.test(preview)) {
      return json({ ok: false, error: 'Tortuga returned a landing page, not a video player',
        kind: 'tortuga_landing', htmlSize: length, upstreamStatus: 200 }, 424,
        { 'X-MultiSource-Upstream-Status': '200' });
    }
    // Preserve UTF-8 HTML; upstream site uses UTF-8. Prevent the browser from executing it.
    return reply(buf, 200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-MultiSource-Upstream-Status': '200',
    });
  }
  return json({ ok: false, error: 'Too many upstream redirects' }, 502);
}
export default {
  async fetch(request) {
    if (request.method === 'OPTIONS') return reply(null, 204);
    if (request.method !== 'GET') return json({ ok: false, error: 'GET only' }, 405);
    const requestUrl = new URL(request.url);
    if (requestUrl.pathname === '/health')
      return json({ ok: true, service: SERVICE, version: '1.0.6' });
    if (requestUrl.pathname !== '/fetch')
      return json({ ok: false, error: 'Use /health or /fetch?url=' }, 404);
    const target = allowed(requestUrl.searchParams.get('url'));
    if (!target) return json({ ok: false, error: 'Only HTTPS uaserials.com, tortuga.wtf and tortuga.tw HTML URLs are allowed' }, 400);
    try { return await fetchPublicPage(target); }
    catch (err) { return json({ ok: false, error: 'Upstream network error', detail: String(err?.message || err) }, 502); }
  }
};
