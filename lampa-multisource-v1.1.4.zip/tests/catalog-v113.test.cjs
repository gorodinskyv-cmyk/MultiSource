const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const file = fs.readFileSync(path.join(__dirname, '..', 'lampa-multisource-v1.1.4.js'), 'utf8');
const marker = '  function rawRequest(url, timeout) {';
assert(file.includes(marker));
const code = file.replace(marker, '  window.__tests = { saveEpisodeLabels, readEpisodeLabels, episodeLabels, findEpisode, resolveWorkerPlayerEntry, resolvePlayerEntry };\n' + marker);
const memory = {};
const requests = [];
let mockedResponse = '';
function Request() { this.timeout = function(){}; this.native = function(url, ok){ requests.push(url); ok(mockedResponse) }; }
const win = { Lampa: { Utils: { hash: s => [...s].reduce((a,c)=>((a*31+c.charCodeAt(0))|0),0) }, Reguest:Request,
  Storage: { get:(key,d)=> key in memory ? memory[key] : d, set:(key,v)=>{memory[key]=v;} } } };
const ctx = {window:win,Lampa:win.Lampa,document:{},atob,TextDecoder,TextEncoder,Promise,Uint8Array,console,
  setTimeout:()=>1,setInterval:()=>1,clearInterval:()=>{},Date,Array,Object,Number};
vm.runInNewContext(code,ctx);
const {saveEpisodeLabels,readEpisodeLabels,findEpisode,resolveWorkerPlayerEntry} = win.__tests;
const title='Кришталеве озеро';
const src='uaserials';
const episodes = n => Array.from({length:n},(_,i)=>({season:1,episode:i+1,voice:'HDrezka Studio',title:'Сезон 1 • Серія '+(i+1),url:`https://example.test/token-${i+1}/index.m3u8`}));
const full=episodes(8), partial=episodes(2);
assert.equal(saveEpisodeLabels(title,src,full).length,8);
assert.equal(saveEpisodeLabels(title,src,partial).length,8, 'shorter response must not erase catalog');
assert.equal(readEpisodeLabels(title,src).length,8);
assert.equal(readEpisodeLabels(title,src)[7].episode,8);
assert.equal(saveEpisodeLabels(title,src,full).length,8, 'repeated full response must not duplicate');
assert.equal(findEpisode(partial,{season:1,episode:8,voice:'HDrezka Studio'}),null);
assert.equal(findEpisode(full,{season:1,episode:8,voice:'HDrezka Studio'}).episode,8);
assert(!JSON.stringify(memory).includes('index.m3u8'), 'signed media URLs must never be saved');
assert(!JSON.stringify(memory).includes('token-'), 'media tokens must never be saved');
win.Lampa.Storage.set('ms_v1_adapter_url','https://example.workers.dev');
const embed={url:'https://tortuga.tw/embed-test', title:'Player', season:0,episode:0,voice:''};
const playlist = Array.from({length:8},(_,i)=>({title:'Серія '+(i+1),file:`https://calypso.tortuga.tw/item${i+1}/index.m3u8`}));
const obj=[{title:'Сезон 1',folder:playlist}];
const enc = Buffer.from(JSON.stringify(obj),'utf8').toString('base64');
mockedResponse = `<html><script>var player = {file: "${enc}"};</script></html>`;
(async()=>{
  const streams = await resolveWorkerPlayerEntry(embed);
  assert.equal(streams.length,8, 'Worker should expose full metadata catalog');
  assert.match(requests[0],/^https:\/\/example\.workers\.dev\/fetch\?url=/);
  assert.equal(saveEpisodeLabels(title,src,streams).length,8);
  const another='Інший серіал';
  assert.equal(saveEpisodeLabels(another,src,partial).length,2);
  assert.equal(saveEpisodeLabels(another,src,streams).length,8,
    'worker enrichment must restore 2→8 episode catalog');
  assert.equal(readEpisodeLabels(another,src).length,8);
  assert.equal((await resolveWorkerPlayerEntry({url:'https://untrusted.invalid/player'})).length,0);
  const db=memory.ms_v1_episode_labels;
  const item=db[Object.keys(db)[0]];
  item.time=Date.now()-25*3600000;
  assert.equal(readEpisodeLabels(title,src).length,0, 'expired catalog must not persist indefinitely');
  console.log('PASS: 8→2 merge, 2→8 enrichment, no signed URLs stored, Worker supplemental catalog');
})().catch(err=>{console.error(err);process.exitCode=1});
