/* Local HTML only. No media proxying, cookies, request logs, or token storage. */
const ALLOWED = new Set(['tortuga.tw', 'tortuga.wtf']);
const MAX_SIZE = 500 * 1024;
function validTarget(input) {
  if (typeof input !== 'string' || input.length > 1900) return null;
  try {
    const url = new URL(input);
    return url.protocol === 'https:' && ALLOWED.has(url.hostname) &&
      !url.port && !url.username && !url.password &&
      !/\.(m3u8|mp4|ts)(?:$|[?#])/i.test(url.pathname) ? url : null;
  } catch { return null; }
}
async function fetchHtml(input) {
  const url = validTarget(input);
  if (!url) return { ok: false, error: 'Unsupported URL' };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(url.href, {
      method: 'GET', credentials: 'omit', redirect: 'error', cache: 'no-store',
      referrerPolicy: 'no-referrer',
      headers: { Accept: 'text/html,application/xhtml+xml' },
      signal: controller.signal
    });
    if (!res.ok) return { ok: false, error: 'Player returned HTTP ' + res.status };
    const kind = (res.headers.get('content-type') || '').toLowerCase();
    if (kind && !/text\/html|application\/xhtml\+xml|text\/plain/.test(kind))
      return { ok: false, error: 'Not HTML' };
    if (Number(res.headers.get('content-length') || 0) > MAX_SIZE)
      return { ok: false, error: 'HTML too large' };
    const reader = res.body?.getReader();
    if (!reader) return { ok: false, error: 'Empty response' };
    const chunks = [];
    let size = 0;
    while (true) {
      const {value, done} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_SIZE) {
        await reader.cancel();
        return { ok: false, error: 'HTML too large' };
      }
      chunks.push(value);
    }
    const all = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { all.set(chunk, offset); offset += chunk.length; }
    const html = new TextDecoder('utf-8').decode(all);
    if (/<title>\s*just a moment|cf-chl|captcha.challenge/i.test(html.slice(0, 8192)))
      return { ok: false, error: 'Interactive challenge required' };
    if (!/\bfile\s*:\s*["']/i.test(html))
      return { ok: false, error: 'No public player metadata available' };
    return { ok: true, html };
  } catch (e) {
    return { ok: false, error: e?.name === 'AbortError' ? 'Timeout' : 'Network error' };
  } finally { clearTimeout(timeout); }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let site;
  try { site = new URL(sender.url || ''); } catch { return false; }
  if (site.origin !== 'https://cf.lampa.mx' || message?.kind !== 'ms-public-player-html')
    return false;
  fetchHtml(message.url).then(sendResponse).catch(() => sendResponse({ok:false,error:'Network error'}));
  return true;
});
