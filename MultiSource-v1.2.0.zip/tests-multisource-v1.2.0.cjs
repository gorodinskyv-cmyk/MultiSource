'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname,'lampa-multisource-v1.2.0.js'),'utf8');
const saved = new Map();
const timelineCalls = [];
const docParser = {
  parseFromString(html) {
    const links = [];
    const pattern = /<a\s+[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m=pattern.exec(html))) {
      const href=m[1], content=m[2].replace(/<[^>]*>/g,' ').trim();
      links.push({
        getAttribute(name) { return name === 'href' ? href : null; },
        textContent: content, querySelector() { return null; }, closest() { return null; }
      });
    }
    return {body: {textContent: html.replace(/<[^>]*>/g,' ')},
      querySelectorAll(sel) {return sel === 'a[href]' ? links : [];},
      querySelector() {return null;} };
  }
};
const Lampa = {
  Storage: {get(k,fallback) {return saved.has(k)?saved.get(k):fallback;}, set(k,v){saved.set(k,v);}},
  Utils: {hash(v){return 'h:' + v;}},
  Timeline: {link(card,season,episode){return {card:'tv_'+card.id,season,episode};},
    view(hash,meta){timelineCalls.push({hash,meta});return {hash,percent:31,time:1234,duration:3600,handler(){}};}},
};
const context = { Lampa, DOMParser: function(){return docParser;}, window: {Lampa, DOMParser: function(){return docParser; }},
  URL, console: {log(){},warn(){},error(){}},
  setInterval() {return 1;}, clearInterval() {}, setTimeout() {return 1;},
  clearTimeout() {}, Date, navigator: {userAgent:''}, location: {protocol:'https:'},
  document: {getElementById(){return null;}},
  TextEncoder, TextDecoder, Uint8Array, atob, AbortController
};
vm.createContext(context);
vm.runInContext(source,context, {timeout:1000});
const api = context.window.LampaMultiSource;
assert.equal(api.version,'1.2.0');
assert.deepEqual(Array.from(api.listSources(), x=>x.id),['uaserials','uafix','uakino']);
const movie={id:123,media_type:'tv', title:'Корона',original_name:'The Crown',first_air_date:'2016-11-04'};
assert.equal(api.helpers.timelineKey(movie,1,2),api.helpers.timelineKey({...movie},1,2));
assert.notEqual(api.helpers.timelineKey(movie,1,2),api.helpers.timelineKey(movie,1,3));
assert.notEqual(api.helpers.timelineKey(movie,1,2),api.helpers.timelineKey({...movie,id:987},1,2));
assert.equal(api.helpers.timelineKey({id:123,title:'Фільм',media_type:'movie'},0,0),'multisource:movie:id:123');
assert.equal(api.helpers.progressFor(movie,1,2).time,1234);
assert.equal(timelineCalls.at(-1).meta.season,1);
const uafix=api.listSources().find(s=>s.id==='uafix');
const uakino=api.listSources().find(s=>s.id==='uakino');
(async()=>{
 const uafixHTML='<a href="/serials/korona-the-crown/">Корона / The Crown</a>';
 const uakinoHTML='<a href="/seriesss/drama_series/6215-korona-1-sezon.html">Корона 1 сезон</a>';
 let requested=[];
 let r=await uafix.search(movie,{request(url){requested.push(url);return Promise.resolve(uafixHTML);}});
 assert.equal(r.length,1);
 assert.equal(r[0].title,'Корона');
 assert.equal(r[0].originalTitle,'The Crown');
 assert.ok(requested[0].includes('uafix.net'));
 requested=[];
 r=await uakino.search(movie,{request(url){requested.push(url);return Promise.resolve(uakinoHTML);}});
 assert.equal(r.length,1);
 assert.equal(r[0].title,'Корона');
 assert.ok(requested[0].includes('uakino.best'));
 const series = '<a href="/serials/korona-the-crown/sezon-1/">Сезон 1</a>';
 const season = '<a href="/serials/korona-the-crown/season-01-episode-01/">1 серія</a>' +
  '<a href="/serials/korona-the-crown/season-01-episode-02/">2 серія</a>';
 const res=await uafix.getStreams({url:'https://uafix.net/serials/korona-the-crown/'},{request(url){
  return Promise.resolve(url.includes('sezon-1') ? season : series);
 }});
 assert.equal(res.streams.length,2);
 assert.equal(res.streams[0].season,1);
 assert.equal(res.streams[1].episode,2);
 assert.equal(res.streams[0].resolvePage,true);
 const video=await uakino.getStreams({url:'https://uakino.best/seriesss/drama_series/6215-korona-1-sezon.html'},
  {request(){return Promise.resolve('<script>var file="https://example.invalid/open.m3u8"</script>');}});
 assert.equal(video.streams.length,1);
 assert.equal(video.streams[0].url,'https://example.invalid/open.m3u8');
 await assert.rejects(uafix.getStreams({url:'https://attacker.invalid/test'},{request(){throw Error('should not send');}}));
 console.log('PASS: core loads, 3 source IDs, stable timeline IDs, UAFix search/episodes, UAKino search/direct media, host restriction');
})().catch(e=>{console.error(e);process.exitCode=1;});
